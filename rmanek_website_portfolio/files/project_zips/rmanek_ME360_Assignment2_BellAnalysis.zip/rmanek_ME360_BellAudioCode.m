%% Settig up Vectors and Variables
%Sampling Frequency:
fs = 100000;

% Create time vector
t = [0:(1/fs):7];

load bell_frequencies.mat;          %Obtained from Solidworks FEA
A = [10 10 1 2 10 10];              %Self Determined through testing
alpha = [0.25 5 5 5 5 1];           %Self Determined through testing

%% Creating y plot of soundwave
temp = zeros(1, length(A));
y = zeros(1, length(t));


for i = 1:1:length(t)
    for j = 1:1:length(A)
        temp(j) = (A(j) * exp(-alpha(j) * t(i)) * sin(bell_frequencies(j) * 2 * pi * (t(j))));
    end
    y(i) = sum(temp);
end


%% Outputs
% Plot the sound data
figure(1),plot(t,y)

% Choose portion of recording to analyze
ind=find(t>=0 & t<=15);
y=y(ind);
t=t(ind);
t=t-t(1);  % Sets first time value to zero

% Plot the chopped signal
figure(2),plot(t,y);

% Compute frequency spectrum
%[w,ty]=fourier(t,y);
%figure(3),plot(w/2/pi,abs(ty));

% Play the chopped audio signal
p = audioplayer(y, fs);
play(p);